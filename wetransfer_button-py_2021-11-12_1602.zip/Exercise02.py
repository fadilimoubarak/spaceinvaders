#!/usr/bin/env python
# -*- coding: utf-8 -*-

# enable functions and methods to manage the Pi
import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
LED1=17
GPIO.setup(LED1, GPIO.OUT)
GPIO.output(LED1, GPIO.LOW)

LED2=4
GPIO.setup(LED2, GPIO.OUT)
GPIO.output(LED2, GPIO.LOW)

 
FRESH = int(input("Veuillez entrer le temps d'intervalle de clignotement : "))


try:
     while True:
        # LED1 : ON ; LED2 : OFF
         GPIO.output(LED1, GPIO.HIGH)
         GPIO.output(LED2, GPIO.LOW)
         # Attendre le temps défini par l'utilisateur
         time.sleep(FRESH)
         # LED1 : OFF ; LED2 : ON
         GPIO.output(LED1, GPIO.LOW)
         GPIO.output(LED2, GPIO.HIGH)
         # Attendre le temps défini par l'utilisateur
         time.sleep(FRESH)
         
         # exceptions are anything that interrupt the try block.
         # if a CTRL_C be pressed
 
except KeyboardInterrupt:
    # setup the GPIO to default values; finish any transmission of energy
    GPIO.cleanup()
