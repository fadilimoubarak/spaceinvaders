#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)

#setting up the Button in GPIO 4
GPIO.setup(4, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#setting up the Led in GPIO 17
LED=17
GPIO.setup(LED, GPIO.OUT)
GPIO.output(LED, GPIO.LOW)
#variable qui va stocker l'état de la Led
led_state = "low"

try:
    while True:
        button_state=GPIO.input(4)
        
        if button_state == False:
            if led_state == "low" :
                GPIO.output(LED, GPIO.HIGH)
                led_state = "high"
                time.sleep(0.05)
            else :
                GPIO.output(LED, GPIO.LOW)
                led_state = "low"
                time.sleep(0.05)
except KeyboardInterrupt:
    GPIO.cleanup()
