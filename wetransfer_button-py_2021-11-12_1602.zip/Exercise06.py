#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)

#setting up the Button for pedestrian in GPIO 27
GPIO.setup(27, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#setting up the RedLed in GPIO 17 
LED1=17
GPIO.setup(LED1, GPIO.OUT)
GPIO.output(LED1, GPIO.LOW)
#OrangeLed2 in GPIO 22
LED2=22
GPIO.setup(LED2, GPIO.OUT)
GPIO.output(LED2, GPIO.LOW)
#GreenLed in GPIO 6
LED3=6
GPIO.setup(LED3, GPIO.OUT)
GPIO.output(LED3, GPIO.LOW)


try:
    while True:
		button_state=GPIO.input(27)
		
		#Le feu passe au vert
		GPIO.output(LED1, GPIO.HIGH)
		
		#If a pedestrian press the button then
		if button_state==False :
			#Le feu passe au orange 2 secondes
			GPIO.output(LED1, GPIO.LOW)
			GPIO.output(LED2, GPIO.HIGH)
			time.sleep(2)
			#Le feu passe au vert 6 secondes
			GPIO.output(LED2, GPIO.LOW)
			GPIO.output(LED3, GPIO.HIGH)
			time.sleep(6)
			GPIO.output(LED3, GPIO.LOW)
		
             
except KeyboardInterrupt:
    GPIO.cleanup()
