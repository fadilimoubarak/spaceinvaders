#!/usr/bin/env python
# -*- coding: utf-8 -*-

# enable functions and methods to manage the Pi
import RPi.GPIO as GPIO
import time
LED=17
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT)
GPIO.output(LED, GPIO.LOW)


FRESH = int(input("Veuillez entrer le temps d'intervalle de clignotement : "))


try:
     while True:
         GPIO.output(LED, GPIO.HIGH)
         # Attendre le temps défini par l'utilisateur
         time.sleep(FRESH)
         GPIO.output(LED, GPIO.LOW)
         # Attendre le temps défini par l'utilisateur
         time.sleep(FRESH)
         
         # exceptions are anything that interrupt the try block.
         # if a CTRL_C be pressed
 
except KeyboardInterrupt:
    # setup the GPIO to default values; finish any transmission of energy
    GPIO.cleanup()
