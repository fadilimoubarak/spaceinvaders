#!/usr/bin/env python
import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)

#setting up the Led1 in GPIO 17 
LED1=17
GPIO.setup(LED1, GPIO.OUT)
GPIO.output(LED1, GPIO.LOW)
#Led2 in GPIO 22
LED2=22
GPIO.setup(LED2, GPIO.OUT)
GPIO.output(LED2, GPIO.LOW)
#Led3 in GPIO 6
LED3=6
GPIO.setup(LED3, GPIO.OUT)
GPIO.output(LED3, GPIO.LOW)

try:
    while True:
        button1_state=GPIO.input(4)
        button2_state=GPIO.input(27)
        button3_state=GPIO.input(5)
        
        if button1_state == False:
            if led1_state == "low" :
                GPIO.output(LED1, GPIO.HIGH)
                led1_state = "high"
                time.sleep(0.05)
            else :
                GPIO.output(LED1, GPIO.LOW)
                led1_state = "low"
                time.sleep(0.05)
        if button2_state == False:
            if led2_state == "low" :
                GPIO.output(LED2, GPIO.HIGH)
                led2_state = "high"
                time.sleep(0.05)
            else :
                GPIO.output(LED2, GPIO.LOW)
                led2_state = "low"
                time.sleep(0.05)
        if button3_state == False:
            if led3_state == "low" :
                GPIO.output(LED3, GPIO.HIGH)
                led3_state = "high"
                time.sleep(0.05)
            else :
                GPIO.output(LED3, GPIO.LOW)
                led3_state = "low"
                time.sleep(0.05)
except KeyboardInterrupt:
    GPIO.cleanup()
