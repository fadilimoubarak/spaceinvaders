#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)

#setting up the RedLed in GPIO 17 
LED1=17
GPIO.setup(LED1, GPIO.OUT)
GPIO.output(LED1, GPIO.LOW)
#OrangeLed2 in GPIO 22
LED2=22
GPIO.setup(LED2, GPIO.OUT)
GPIO.output(LED2, GPIO.LOW)
#GreenLed in GPIO 6
LED3=6
GPIO.setup(LED3, GPIO.OUT)
GPIO.output(LED3, GPIO.LOW)


try:
    while True:
		#Le feu passe au vert pendant 5 secondes
		GPIO.output(LED3, GPIO.HIGH)
		time.sleep(5)
		GPIO.output(LED3, GPIO.LOW)
		
		#Le feu passe au orange pendant 1 seconde
		GPIO.output(LED2, GPIO.HIGH)
		time.sleep(1)
		GPIO.output(LED2, GPIO.LOW)
		
		#Le feu passe au rouge pendant 5 seconde
		GPIO.output(LED1, GPIO.HIGH)
		time.sleep(5)
		GPIO.output(LED1, GPIO.LOW)
		
             
except KeyboardInterrupt:
    GPIO.cleanup()
