#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
Buzzer = 17
FRESH = 2
GPIO.setmode(GPIO.BCM)
GPIO.setup(Buzzer, GPIO.OUT)
GPIO.output(Buzzer, GPIO.HIGH)

try:
    while True:
        GPIO.output(Buzzer, GPIO.HIGH)
        time.sleep(FRESH)
        GPIO.output(Buzzer, GPIO.LOW)
        time.sleep(FRESH)

except KeyboardInterrupt:
    GPIO.cleanup()

