#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)

#setting up the Button in GPIO 4
GPIO.setup(4, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#setting up the Led in GPIO 17
LED=17
GPIO.setup(LED, GPIO.OUT)
GPIO.output(LED, GPIO.LOW)

try:
    while True:
        button_state=GPIO.input(4)
        if button_state == True:
            GPIO.output(LED, GPIO.LOW)
        else :
            GPIO.output(LED, GPIO.HIGH)
            
except KeyboardInterrupt:
    GPIO.cleanup()
