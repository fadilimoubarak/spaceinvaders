#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)

#setting up the Button for pedestrian in GPIO 26
GPIO.setup(26, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#setting the Buzzer in GPIO 27
Buzzer = 27
GPIO.setup(Buzzer, GPIO.OUT)
GPIO.output(Buzzer, GPIO.LOW)

#setting up the RED in GPIO 17 
LED1=17
GPIO.setup(LED1, GPIO.OUT)
GPIO.output(LED1, GPIO.LOW)
#YELLOW in GPIO 22
LED2=22
GPIO.setup(LED2, GPIO.OUT)
GPIO.output(LED2, GPIO.LOW)
#GREEN in GPIO 6
LED3=6
GPIO.setup(LED3, GPIO.OUT)
GPIO.output(LED3, GPIO.LOW)

rep = 1

try:
    while True:
		button_state=GPIO.input(26)
		
		#Le feu passe au rouge
		GPIO.output(LED1, GPIO.HIGH)
		if rep == 1 :
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.HIGH)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.LOW)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.HIGH)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.LOW)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.HIGH)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.LOW)
			rep = 2
		
		#If a pedestrian press the button then
		if button_state==False :
			#Le feu passe au orange 2 secondes
			GPIO.output(LED1, GPIO.LOW)
			GPIO.output(LED2, GPIO.HIGH)
			
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.HIGH)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.LOW)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.HIGH)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.LOW)
			
			time.sleep(2)
			#Le feu passe au vert 6 secondes
			GPIO.output(LED2, GPIO.LOW)
			GPIO.output(LED3, GPIO.HIGH)
			
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.HIGH)
			time.sleep(0.5)
			GPIO.output(Buzzer, GPIO.LOW)
			
			time.sleep(2)
			GPIO.output(LED3, GPIO.LOW)
			rep = 1
		
             
except KeyboardInterrupt:
    GPIO.cleanup()
