#!/usr/bin/env python
# -*- coding: utf-8 -*-

import RPi.GPIO as GPIO
import time
import random
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#setting up the Red in GPIO 17 
RED=17
GPIO.setup(RED, GPIO.OUT)
GPIO.output(RED, GPIO.LOW)
#Blue in GPIO 22
BLUE=22
GPIO.setup(BLUE, GPIO.OUT)
GPIO.output(BLUE, GPIO.LOW)
#Green in GPIO 6
GREEN=6
GPIO.setup(GREEN, GPIO.OUT)
GPIO.output(GREEN, GPIO.LOW)

try:
	print("Bienvenue sur notre jeu de devinette !\n")
	secret = random.randint(1, 20)
	nb_attempt = 4
	print(secret)
	game_state="PLAYING"
	while game_state != "FIN" :
		print("Tentative restante : ", nb_attempt)
		attempt = int(input("Essayez de devinez un numéro entre 1 et 20 : "))
		if attempt == secret :
			print("Vous avez gagnez !! You Won !!")
			GPIO.output(GREEN, GPIO.HIGH)
			time.sleep(5)
			game_state="FIN"
			GPIO.output(GREEN, GPIO.LOW)
		elif attempt > secret :
			print("Le nombre secret est plus petit... Lower...")
			GPIO.output(BLUE, GPIO.HIGH)
			time.sleep(5)
			GPIO.output(BLUE, GPIO.LOW)
			nb_attempt = nb_attempt - 1
		else :
			print("Raté !! You've missed !!")
			GPIO.output(RED, GPIO.HIGH)
			time.sleep(5)
			GPIO.output(RED, GPIO.LOW)
			nb_attempt = nb_attempt - 1
			
		if 	nb_attempt == 0 :
			game_state = "FIN"
			print("Vous avez perdu... à la prochaine !!")
		
except KeyboardInterrupt:
    GPIO.cleanup()
